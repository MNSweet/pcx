console.log("This is PL specific content script.");

/********************************************
*
* Import Patient Data from Local Temp Cache.
*
*********************************************/

// content_pl.js
const fieldMappingPL = {
  FirstName: '#plFirstName',
  LastName: '#plLastName',
  // Add more mappings as needed
};

function pastePLPatientData() {
  chrome.storage.local.get('patientData', ({ patientData }) => {
    if (patientData) {
      Object.keys(fieldMappingPL).forEach(key => {
        const inputSelector = fieldMappingPL[key];
        const inputElement = document.querySelector(inputSelector);
        if (inputElement) {
          inputElement.value = patientData[key];
        }
      });

      // Clear the patient data after usage
      chrome.storage.local.set({ patientData: {} }, () => {
        console.log('PL Patient data cleared after use');
      });
    }
  });
}

// Add a button to paste PL patient data
const plButton = document.createElement('button');
plButton.textContent = 'Paste Patient Data';
plButton.style.cssText = 'position:fixed; bottom:10px; right:10px; z-index:1000;';
plButton.onclick = pastePLPatientData;
//document.body.appendChild(plButton);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'startCountdownBanner') {
    // If the banner is already present, don't recreate it
    if (!document.querySelector('#patientDataBanner')) {
      initializeBanner(message.patientData);
    }
  }
});
