const PCX_DEBUG = true; // Toggle this to enable/disable debug logs

function pcxDebug(message) {
  if (PCX_DEBUG) {
    console.log(message);
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'setNotification') {
    const notifId = request.notifId;
    const remindTime = request.remindTime;
    const title = request.title;
    const message = request.message;

    // Check if the reminder for this notification ID is set
    chrome.storage.local.get(["pcxid_" + notifId], (result) => {
      const remindUntil = result["pcxid_" + notifId];
      const currentTime = Date.now();

      if (!remindUntil || currentTime > remindUntil) {
        // Show the Chrome notification
        chrome.notifications.create(notifId, {
          type: 'basic',
          iconUrl: 'icon.png',
          title: title,
          message: message,
          priority: 2
        }, () => {
          pcxDebug(`Chrome notification shown for ${notifId}`);
        });

        // If the user selected a reminder time, save it
        if (remindTime > 0) {
          chrome.storage.local.set({ ["pcxid_" + notifId]: currentTime + remindTime * 3600000 }, () => {
            pcxDebug(`Reminder set for ${notifId}, do not show again for ${remindTime} hours`);
          });
        }
      } else {
        pcxDebug(`Notification for ${notifId} suppressed until reminder expires`);
      }
    });

    sendResponse({ status: "notification handled" });
  }

  if (request.action === 'clearReminder') {
    const notifId = request.notifId;

    chrome.storage.local.remove("pcxid_" + notifId, () => {
      pcxDebug(`Cleared reminder for ${notifId}`);
    });

    sendResponse({ status: "reminder cleared" });
  }
});

// Function to get the current site
function getCurrentSite() {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0]?.url;
      if (url.includes("pr.local")) {
        resolve("PR.local");
      } else if (url.includes("rr.local")) {
        resolve("RR.local");
      } else if (url.includes("pl.local")) {
        resolve("PL.local");
      } else {
        reject("Site not recognized.");
      }
    });
  });
}

// Example usage of getCurrentSite function
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getSite") {
    getCurrentSite().then((site) => {
      sendResponse({ site: site });
    }).catch((error) => {
      sendResponse({ error: error });
    });
    return true; // Indicates the response will be sent asynchronously
  }
});