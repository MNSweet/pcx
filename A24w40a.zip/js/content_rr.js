console.log("This is RR specific content script.");

// Function to handle the click event and get the row data
function handleDownloadClick(event) {
  //event.preventDefault(); // Prevent the default link behavior [For testing, should be commented out]

  const headings = document.getElementById('MainContent_ctl00_grid_DXHeadersRow0').textContent.replaceAll('\t','').replaceAll('\n','').split(" ");
  // Check if the clicked element or one of its parents is the <a> with title "Download Result"
  const clickedLink = event.target.closest('a[title="Download Result"]');

  // If the clicked element matches the <a> tag we care about
  if (clickedLink) {
    // Find the parent <tr> for the clicked <a>
    const row = clickedLink.closest('tr');

    // Collect the text content of all <td> elements in the row into an array
    const rowData = Array.from(row.querySelectorAll('td')).map(td => td.textContent.trim());
    
    const date = new Date();
    return "Results "
          +`${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()} `
          +rowData[headings.indexOf('Last')]
          +" "
          +rowData[headings.indexOf('First')]; // Output the row data as an array
  }
}

// Attach the event listener to a common ancestor of the dynamically replaced content
document.body.addEventListener('click', function(event) {
  // Only process clicks inside the dynamically replaced div#MainContent_ctl00_updatePanel1
  if (event.target.closest('#MainContent_ctl00_updatePanel1') && event.target.closest('a[title="Download Result"]')) {
    PCX_CMSInteraction.copyToClipboard(handleDownloadClick(event));
  }
});
